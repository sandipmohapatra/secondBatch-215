package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBatch215example3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBatch215example3Application.class, args);
	}

}
