package com.example.demo;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController 
{

	@Autowired
	private JdbcTemplate jt;//file which connect java with database.
	
	
	@GetMapping("/reg")
	public String showRegister()
	{
		return "Register";
	}
	@RequestMapping("/save")
	public String doRegister(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		String e=req.getParameter("t5");
		String f=req.getParameter("t6");
		String sql="insert into Mstudent values(?,?,?,?,?,?)"; 
		jt.update(sql,a,b,c,d,e,f);
						return "success";
			}
	
	
}
